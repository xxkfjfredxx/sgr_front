import { Button as MTButton } from "@material-tailwind/react";

export function Button(props) {
  return <MTButton {...props} />;
}