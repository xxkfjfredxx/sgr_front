export const employeesTableData = [
    {
      img: "/avatars/1.jpg",
      name: "Carolina Rueda",
      email: "carolina@empresa.com",
      document: "1098765432",
      role: ["Manager", "RRHH"],
      status: "active",        // viable values: 'active' | 'inactive'
      hiredDate: "2023-04-15",
      birthDate: "1992-01-01",
    },
    // … más empleados
  ];