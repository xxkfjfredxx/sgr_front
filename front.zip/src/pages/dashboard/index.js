export * from "@/pages/dashboard/CalendarDashboard";
export * from "@/pages/dashboard/profile";
export * from "@/pages/dashboard/tables";
export * from "@/pages/dashboard/notifications";
export { default as CalendarDashboard } from "@/pages/dashboard/CalendarDashboard";
