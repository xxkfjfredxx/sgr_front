export { default as MedicalExamSelfPage } from "./MedicalExamSelfPage";
