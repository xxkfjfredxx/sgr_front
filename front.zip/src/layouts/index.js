export { default as Dashboard } from "./dashboard"; // ✅ Layout principal
export { default as Auth } from "./auth";  